/**
 * @author JS
 * @creat 2021-03-20-19:12
 */

import java.util.HashMap;
import java.util.Scanner;

/**
 *类功能描述
 *@Authorkeyter
 *@Date 2021/3/20 19:12
 */
public class MainClass {
    public static void main(String[] args){
    Scanner scanner = new Scanner(System.in);
        HashMap<String, student> hashMap = new HashMap <>();

        System.out.println("make your choice:\n" +
                "1 -> create an student\n" +
                "2 -> updata an student\n" +
                "3 -> read an student\n" +
                "4 -> delete an student\n" +
                "5 -> out\n" +
                "choice = ");
        int choice = scanner.nextInt();
        StringBuilder name = new StringBuilder(10);
        int age ;
        double score;
        while (choice != 5){
            switch (choice){
            case 1 :
                System.out.println("input student name :");
                name.append(scanner.next());
                System.out.println("input "+ name +  "'s age:");
                age = scanner.nextInt();
                System.out.println("input "+ name +  "'s score:");
                score = scanner.nextDouble();
                System.out.println("input "+ name +  "'s score:");
                student s = new student(name.toString(),age,score);
                hashMap.put(name.toString(), s);
                name.delete(0,name.length());
                break;
            case 2 :
                System.out.println("input student name :");
                name.append(scanner.next());
                student stu = hashMap.get(name.toString());
                if(stu != null){
                System.out.println("input "+ name +  "'s age:");
                age = scanner.nextInt();
                System.out.println("input "+ name +  "'s score:");
                score = scanner.nextDouble();
                System.out.println("input "+ name +  "'s score:");
                stu.updataStudent(name.toString(),age, score);
                }
                name.delete(0,name.length());
                break;
            case 3:
                System.out.println("input student name :");
                name.append(scanner.next());
                student stud = hashMap.get(name.toString());
                if(stud != null){
                    stud.readStudent();
                }
                name.delete(0,name.length());
                break;
            case 4:
                System.out.println("input student name :");
                name.append(scanner.next());
                student stude = hashMap.get(name.toString());
                if (stude != null){
                hashMap.remove(name.toString());
                }
                name.delete(0,name.length());
                break;

          }
            System.out.println("make your choice:\n" +
                    "1 -> create an student\n" +
                    "2 -> updata an student\n" +
                    "3 -> read an student\n" +
                    "4 -> delete an student\n" +
                    "5 -> out\n" +
                    "choice = ");
            choice = scanner.nextInt();
        }
    }
}
