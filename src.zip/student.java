/**
 * @author JS
 * @creat 2021-03-20-19:13
 */

/**
 *类功能描述
 *@Authorkeyter
 *@Date 2021/3/20 19:13
 */
public class student {
    double score;

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    int age ;
    String name ;
    student(){
        score = 0;
        age = -1;
        name = "null";
    }
    student(String name, int age, double score){
        this.name = name;
        this.age= age;
        this.score = score;
    }
    void updataStudent(String name, int age, double score ){
        this.name = name;
        this.age= age;
        this.score = score;
    }
    public void readStudent(){
        System.out.println(name + "'s age is:" + age + " and score is :" + score);
    }
}
